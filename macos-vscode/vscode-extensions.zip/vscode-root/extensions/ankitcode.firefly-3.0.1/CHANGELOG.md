# Change Log

### Version 2.0.0

* fixed menu background issue
* fixed focus color issue in sidebar
* fixed dropdown colors
* chnaged terminal tab colors
* chnaged breadcrumb colors
* changed scrollbar colors
* chnaged selection colors
* changed sidebar colors
* changed editor colors
* changed input colors
* changed Tab colors
* changed Panel colors
* complete changed in activity icon, badge colors
* chnaged status bar colors
* changed string colors
* complete chnaged and fixes in sidebar lists
* changed colors for welcome page
* added active, inactive window color feature



